# Bus-booking-system-Java

A basic Bus Ticket Booking Application developed using Java Swing backed by MySQL database in the backend

Admin Functionalities: Add a new Bus, View all Bus Details, Edit Bus Details, Delete a Bus, Edit Ticket Prices, Block Tickets

Client Functionalities: Sign Up, Sign In, Edit Personal Details, Book a Ticket, View Booked Tickets, Cancel Tickets
